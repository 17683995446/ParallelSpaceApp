plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.parallelspace.app.business_ability.clone_create"
    compileSdk = 34
    defaultConfig {
        minSdk = 26
        consumerProguardFiles("$consumerProguardFiles")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
dependencies {
    implementation(project(":system_kernel:sandbox_isolate"))
    implementation(project(":system_kernel:process_control"))
}
